import pandas as pd
from pretraining_tests import PretrainTests

df=pd.read_csv("hotels.csv",index_col=0)
exp_df=df[df.ReservationStatusDate<'2015-10-17']
test_df=df[df.ReservationStatusDate>='2015-10-17']

test=PretrainTests(exp_df,test_df)
expectations=test.get_expectations()
test_results=test.run_tests(expectations)
print(test_results)